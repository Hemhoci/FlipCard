# RotatingCard

A Pen created on CodePen.io. Original URL: [https://codepen.io/JuarrenCodes2020/pen/abqvBbG](https://codepen.io/JuarrenCodes2020/pen/abqvBbG).

